@extends('layouts.app')

@section('title', 'Gallery Master')

@section('content')
<div class="main-content">
    <div class="page-content">
        <div class="container-fluid">
            {{-- Alert Messages --}}
            @include('common.alert')
            <div class="row">
                <!-- Left Side: Form -->
                <div class="col-md-4">
                    <div class="card">
                        <div class="card-header">Add Gallery Image</div>
                        <div class="card-body">
                            <form action="{{ route('admin.gallery_master.store') }}" method="POST" enctype="multipart/form-data">
                                @csrf
                                <div class="mb-3">
                                    <label class="form-label">Image <span style="color:red;">*</span></label>
                                    <input type="file" name="image" class="form-control">
                                    @if($errors->has('image'))
                                        <span class="text-danger">
                                            {{ $errors->first('image') }}
                                        </span>
                                    @endif
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Status</label>
                                    <select name="iStatus" class="form-control">
                                        <option value="1">Active</option>
                                        <option value="0">Inactive</option>
                                    </select>
                                </div>

                                <button type="submit" class="btn btn-success">Submit</button>
                            </form>
                        </div>
                    </div>
                </div>

                <!-- Right Side: Listing -->
                <div class="col-md-8">
                    <div class="card">
                        <div class="card-header d-flex justify-content-between">
                            <span>Gallery Listing</span>
                            <button id="bulkDelete" class="btn btn-danger btn-sm">Delete Selected</button>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th><input type="checkbox" id="checkAll"></th>
                                            <th>Image</th>
                                            <th>Created At</th>
                                            <th>Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach($gallery as $item)
                                            <tr>
                                                <td><input type="checkbox" class="recordCheckbox" value="{{ $item->gallery_id }}"></td>
                                                <td><img src="{{ asset('gallery_master/'.$item->image) }}" width="70"></td>
                                                <td>{{ $item->created_at }}</td>
                                                <td>
                                                    <form action="{{ route('admin.toggle-status', $item->gallery_id) }}" method="POST">
                                                        @csrf 
                                                        <button class="btn btn-sm toggle-status {{ $item->iStatus ? 'btn-success' : 'btn-warning' }}">
                                                            {{ $item->iStatus ? 'Active' : 'Inactive' }}
                                                        </button>
                                                    </form>
                                                </td>
                                                <td>
                                                    <a href="javascript:void(0);" class="btn btn-sm btn-primary editGallery" data-id="{{ $item->gallery_id }}">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    <form class="d-inline" method="POST" action="{{ route('admin.gallery_master.destroy', $item->gallery_id) }}" onsubmit="return confirm('Delete this album?')">
                                                      @csrf @method('DELETE')
                                                      <button class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></button>
                                                    </form>
                                                    <!--<a href="javascript:void(0);" class="btn btn-sm btn-danger deleteGallery" data-id="{{ $item->gallery_id }}">-->
                                                    <!--        <i class="fas fa-trash-alt"></i>-->
                                                    <!--    </a>-->

                                                </td>
                                            </tr>
                                        @endforeach
                                    </tbody>
                                </table>
                                <div class="d-flex justify-content-center mt-3">
                                    {{ $gallery->links() }}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal for Edit will be added here -->
@include('admin.gallery_master.edit-modal')
@endsection

@section('scripts')
<script>
$(document).ready(function () {
    // Open modal and load gallery data
    $('.editGallery').on('click', function () {
        let galleryId = $(this).data('id');
        $.get("{{ url('admin/gallery_master/edit') }}/" + galleryId, function (data) {
            $('#edit_gallery_id').val(data.gallery_id);
            $('#edit_album_id').val(data.album_id);
            $('#current_image').attr('src', "{{ asset('gallery_master') }}/" + data.image);
            $('#edit_status').val(data.iStatus);
            $('#editGalleryForm').attr('action', "{{ url('admin/gallery_master/update') }}/" + galleryId);
            $('#editModal').modal('show');
        });
    });

    // Select/Deselect All
    $('#checkAll').on('click', function () {
        $('.recordCheckbox').prop('checked', this.checked);
    });

    // Bulk Delete Confirmation
    $('#bulkDelete').on('click', function () {
        if (confirm("Are you sure you want to delete selected items?")) {
            let ids = $(".recordCheckbox:checked").map(function () {
                return $(this).val();
            }).get();

            if (ids.length > 0) {
                $.ajax({
                    url: "{{ route('admin.gallery_master.bulk-delete') }}",
                    type: "POST",
                    data: {
                        _token: "{{ csrf_token() }}",
                        ids: ids
                    },
                    success: function (response) {
                        location.reload();
                    }
                });
            } else {
                alert("Please select at least one record to delete.");
            }
        }
    });
});
// Single Delete with confirmation
$('.deleteGallery').on('click', function () {
    const galleryId = $(this).data('id');

    if (confirm("Are you sure you want to delete this image?")) {
        $.ajax({
            url: "{{ url('admin/gallery_master/delete') }}/" + galleryId,
            type: "POST",
            data: {
                _method: 'DELETE',
                _token: "{{ csrf_token() }}"
            },
            success: function (response) {
                location.reload();
            },
            error: function () {
                alert('Failed to delete. Please try again.');
            }
        });
    }
});

</script>
@endsection
